Remember first run:
1. Click right this app
2. Choice Open and use the app

And next run you can double-click for run app

You can view images for detail



Don't double-click open app on first open, dialog "Move to trash" and "Cancel" will be displayed. Let do follow on head text for run it



Thanks
wwww.GameThapCam.Com